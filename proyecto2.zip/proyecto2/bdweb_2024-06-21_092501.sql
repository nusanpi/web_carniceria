-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bdweb
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `detalle`
--

DROP TABLE IF EXISTS `detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle` (
  `codigo_pedido` int(11) NOT NULL,
  `codigo_producto` int(11) NOT NULL,
  `unidades` int(11) DEFAULT NULL,
  `precio_unitario` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`codigo_pedido`,`codigo_producto`),
  KEY `contiene` (`codigo_producto`),
  CONSTRAINT `contiene` FOREIGN KEY (`codigo_producto`) REFERENCES `productos` (`codigo`),
  CONSTRAINT `referentea` FOREIGN KEY (`codigo_pedido`) REFERENCES `pedidos` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle`
--

/*!40000 ALTER TABLE `detalle` DISABLE KEYS */;
INSERT INTO `detalle` VALUES (3,2,1,25.99),(4,2,1,25.99),(4,3,1,2.95),(5,2,1,25.99),(6,2,1,25.99),(7,1,2,12.90),(7,3,1,2.95),(8,1,2,12.90),(8,3,1,2.95),(9,1,2,12.90),(10,1,2,12.90),(11,3,1,2.95),(12,2,1,25.99),(13,2,10,25.99),(14,2,2,25.99),(14,3,2,2.95),(15,2,1,25.99),(16,3,1,2.95),(17,1,1,12.90),(17,2,1,25.99),(17,3,1,2.95),(17,10,1,4.50),(17,11,1,5.95),(17,12,1,16.00),(17,13,1,7.00),(17,14,1,8.50),(17,15,1,11.90),(17,16,1,6.00),(17,17,1,9.99),(17,18,1,10.00),(17,19,1,7.99),(17,20,1,10.75),(17,21,1,6.45),(18,11,1,5.95),(19,3,1,2.95),(20,3,1,2.95),(21,2,1,25.99),(22,1,10,12.90),(23,2,3,25.99),(23,3,2,2.95),(23,12,1,16.00),(24,11,1,5.95);
/*!40000 ALTER TABLE `detalle` ENABLE KEYS */;

--
-- Table structure for table `estados`
--

DROP TABLE IF EXISTS `estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estados` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estados`
--

/*!40000 ALTER TABLE `estados` DISABLE KEYS */;
INSERT INTO `estados` VALUES (1,'Pendiente'),(2,'Enviado'),(3,'Entregado'),(4,'Cancelado');
/*!40000 ALTER TABLE `estados` ENABLE KEYS */;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `persona` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `importe` decimal(8,2) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  KEY `pedidopor` (`persona`),
  KEY `enestado` (`estado`),
  CONSTRAINT `enestado` FOREIGN KEY (`estado`) REFERENCES `estados` (`codigo`),
  CONSTRAINT `pedidopor` FOREIGN KEY (`persona`) REFERENCES `usuarios` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES (3,56,'2024-05-02',25.99,2),(4,56,'2024-05-02',28.94,3),(5,56,'2024-05-02',25.99,4),(6,56,'2024-05-02',25.99,4),(7,56,'2024-05-02',28.75,4),(8,56,'2024-05-02',28.75,4),(9,56,'2024-05-03',25.80,1),(10,56,'2024-05-03',25.80,4),(11,56,'2024-05-03',2.95,4),(12,67,'2024-05-03',25.99,4),(13,67,'2024-05-03',259.90,4),(14,56,'2024-05-03',57.88,1),(15,56,'2024-05-03',25.99,1),(16,56,'2024-05-03',2.95,1),(17,56,'2024-05-03',146.87,4),(18,56,'2024-05-04',5.95,1),(19,67,'2024-05-04',2.95,2),(20,67,'2024-05-05',2.95,1),(21,67,'2024-05-05',25.99,1),(22,67,'2024-05-05',129.00,1),(23,76,'2024-06-06',99.87,3),(24,76,'2024-06-06',5.95,4);
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) DEFAULT NULL,
  `precio` decimal(8,2) DEFAULT NULL,
  `existencias` int(11) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `categoria` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'Filetes de ternera',12.90,0,'img/p1.jpg','Ternera'),(2,'Chuletas de cordero',25.99,3,'img/p2.jpg','Cordero'),(3,'Hamburguesa',2.95,6,'img/Hamburguesa.jpg','Pollo'),(10,'Alitas de pollo',4.50,10,'img/alitas-de-pollo.jpg','Pollo'),(11,'Muslos de pollo',5.95,9,'img/muslos_pollo.jpg','Pollo'),(12,'Jamón serrano',16.00,10,'img/jamon_serrano.png','Fiambre'),(13,'Morcilla',7.00,10,'img/morcilla.jpg','Embutido'),(14,'Sobrasada',8.50,10,'img/sobrasada.jpg','Embutido'),(15,'Lomo de cerdo',11.90,10,'img/lomo_cerdo.jpg','Cerdo'),(16,'Fuet',6.00,10,'img/Fuet.jpg',NULL),(17,'Jamon york',9.99,10,'img/jamon_york.jpg','Fiambre'),(18,'Longanizas ',10.00,10,'img/longanizas.jpg',NULL),(19,'Panceta',7.99,10,'img/panceta.jpeg',NULL),(20,'Solomillo de cerdo',10.75,10,'img/solomillo_cerdo.jpg','Cerdo'),(21,'Pechuga de pollo',6.45,10,'img/pechuga_pollo.jpg','Pollo');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `activo` int(11) DEFAULT NULL,
  `admin` int(11) DEFAULT NULL,
  `usuario` varchar(32) DEFAULT NULL,
  `clave` varchar(32) DEFAULT NULL,
  `nombre` varchar(64) DEFAULT NULL,
  `direccion` varchar(128) DEFAULT NULL,
  `cp` char(5) DEFAULT NULL,
  `telefono` char(9) DEFAULT NULL,
  `correo` varchar(59) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,0,1,'morch','morch','tt','','','',''),(56,1,1,'xx','xx','nuria','mi cas','57','123','nurisanpi@gmail.com'),(57,0,0,'d','d','NURIA SANCHIS','Urbanizacion Las Fuentes Mas Camarena','46117','66558667','nurisanpi@gmail.com'),(67,0,0,'lalaia','lalaia','LAIA MOLINA','LAS DENIAS','03700','123456789','nurisanpi@gmail.com'),(75,0,0,'final','final','final','Urbanizacion Las Fuentes Mas Camarena','46117','665586672','nurisanpi@gmail.com'),(76,0,0,'raul','12345','Raúl Peña Ortiz','calle mayor numero 1','46120','666666666','raul.penya@uv.es');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;

--
-- Dumping routines for database 'bdweb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-21  9:25:22
