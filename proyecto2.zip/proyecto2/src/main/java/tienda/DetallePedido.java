package tienda;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 
public class DetallePedido extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int codigoPedido = Integer.parseInt(request.getParameter("codigoPedido"));
        
        AccesoBD accesoBD = AccesoBD.getInstance();
        List<Detalles> detallesPedido = accesoBD.verDetallesPedido(codigoPedido);
        
        request.setAttribute("detallesPedido", detallesPedido);
        
        request.getRequestDispatcher("detallespedido.jsp").forward(request, response);
       
        
    }
}
