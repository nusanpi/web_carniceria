package tienda;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.json.*;
import java.io.*;
import java.util.ArrayList;

public class RecogerCarrito extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        ArrayList<Producto> carritoJSON = new ArrayList<Producto>();
        HttpSession session = request.getSession();

        // Lee el JSON enviado desde el cliente
        JsonReader jsonReader = Json.createReader(
            new InputStreamReader(
                request.getInputStream(),"utf-8"));

        JsonArray jobj = jsonReader.readArray();
    

        // Procesa los datos del carrito
        for (int i = 0; i < jobj.size(); i++) {
            JsonObject prod = jobj.getJsonObject(i);
            Producto nuevo = new Producto();
            nuevo.setCodigo(prod.getInt("codigo"));
            nuevo.setNombre(prod.getString("nombre"));
            nuevo.setPrecio(Float.parseFloat(prod.get("precio").toString()));
            nuevo.setCantidad(prod.getInt("cantidad"));
            carritoJSON.add(nuevo);
        }

        // Verifica el stock y otros aspectos de los productos en el carrito
        AccesoBD accesoBD = AccesoBD.getInstance();
       
        ArrayList<Producto> carritoJSONFinal = new ArrayList<Producto>();

        for (Producto productoCarrito : carritoJSON) {
            ProductoBD productoBD = accesoBD.obtenerProductoBDcodigo(productoCarrito.getCodigo());
        
                if (productoCarrito.getCantidad() <= productoBD.getStock()) {
                    carritoJSONFinal.add(productoCarrito);
                    
                }

                else {
                    if (productoBD.getStock()>0){
                        productoCarrito.setCantidad(productoBD.getStock());
                        carritoJSONFinal.add(productoCarrito);
                    }
                }
            
        }        
        session.setAttribute("carrito", carritoJSONFinal);
        request.getRequestDispatcher("/resguardo.jsp").forward(request, response);
    }
}
