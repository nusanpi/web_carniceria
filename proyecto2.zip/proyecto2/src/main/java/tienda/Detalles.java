package tienda;



public class Detalles {
    private int codigo_pedido;
    private int codigo_producto;
    private int unidades;
    private float precio_unitario;
    private String descripcion_producto;

    public int getCodigo_pedido() {
        return codigo_pedido;
    }
    public void setCodigo_pedido(int codigo_pedido) {
        this.codigo_pedido = codigo_pedido;
    }
    public int getCodigo_producto() {
        return codigo_producto;
    }
    public void setCodigo_producto(int codigo_producto) {
        this.codigo_producto = codigo_producto;
    }
    public int getUnidades() {
        return unidades;
    }
    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }
    public float getPrecio_unitario() {
        return precio_unitario;
    }
    public void setPrecio_unitario(float precio_unitario) {
        this.precio_unitario = precio_unitario;
    }
    public String getDescripcion_producto() {
        return descripcion_producto;
    }

    public void setDescripcion_producto(String descripcion_producto) {
        this.descripcion_producto = descripcion_producto;
    }
}
