package tienda;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

 
public class EliminarPedido extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         
        int codigoPedido = Integer.parseInt(request.getParameter("codigoPedido"));

        
        AccesoBD accesoBD = AccesoBD.getInstance();
        Pedidos pedido = accesoBD.obtenerPedido(codigoPedido);
        if (pedido != null && pedido.getEstado() == 1) {
             
             List<Detalles> detallesPedido = accesoBD.obtenerDetallesPedido(codigoPedido);
            
             
            for (Detalles detalle : detallesPedido) {
                accesoBD.sumarExistenciasProducto(detalle.getCodigo_producto(), detalle.getUnidades());
            }
            boolean exito = accesoBD.eliminarPedido(codigoPedido);
            if (exito) {
                 
                response.sendRedirect("mostrarPedidos.html");
            } else {
                
                request.setAttribute("mensaje", "Error al eliminar el pedido. Inténtelo de nuevo.");
                response.sendRedirect("mostrarPedido.html");
            }
        } else {
             
            response.sendRedirect("mostrarPedidos.html");
        }
    }

}
