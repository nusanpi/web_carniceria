package tienda;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ModificarDireccionCP  extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String pCodigo = request.getParameter("codigo");
        String direccion = request.getParameter("direccion");
        String CP = request.getParameter("CP");
        String url = request.getParameter("url");

        int codigo = 0;

        if (pCodigo != null) {
            codigo = Integer.parseInt(pCodigo);
        }

        UsuarioBD usuarioActualizado = new UsuarioBD();
        usuarioActualizado.setCodigo(codigo);
        usuarioActualizado.setDireccion(direccion);
        usuarioActualizado.setCP(CP);

        boolean exito = AccesoBD.getInstance().modificarDireccionCPUsuarioBD(usuarioActualizado);

        if (exito) {

            request.setAttribute("usuario", usuarioActualizado);
            request.getRequestDispatcher(url).forward(request, response);
        } else {
            
            request.setAttribute("mensaje", "Error al modificar la dirección y el código postal. Inténtelo de nuevo.");
            response.sendRedirect("carrito.jsp");
        }
    }
}
