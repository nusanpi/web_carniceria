package tienda;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ModificarMostrarUsuario extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    String pCodigo = request.getParameter("codigo");
    String nombreUsuario = request.getParameter("usuario");
    String clave = request.getParameter("clave");
    String nombre = request.getParameter("nombre");
    String direccion = request.getParameter("direccion");
    String CP = request.getParameter("CP");
    String telefono = request.getParameter("telefono");
    String correo = request.getParameter("correo");
    String url = request.getParameter("url");

    int codigo = 0;

    if (pCodigo != null) {
        codigo = Integer.parseInt(pCodigo);
    }

    UsuarioBD usuarioActualizado = new UsuarioBD();
    usuarioActualizado.setCodigo(codigo);
    usuarioActualizado.setUsuario(nombreUsuario);
    usuarioActualizado.setClave(clave);
    usuarioActualizado.setNombre(nombre);
    usuarioActualizado.setDireccion(direccion);
    usuarioActualizado.setCP(CP);
    usuarioActualizado.setTelefono(telefono);
    usuarioActualizado.setCorreo(correo);

    boolean exito = AccesoBD.getInstance().modificarUsuarioBD(usuarioActualizado);

    if (exito) {
        request.setAttribute("usuario", usuarioActualizado);
        request.getRequestDispatcher(url).forward(request, response);
    } else {

        response.sendRedirect("infousuario.jsp");
    }
}

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    

    String pCodigo = request.getParameter("codigo");
    UsuarioBD usuario = null;

    if (pCodigo != null) {
        int codigo = Integer.parseInt(pCodigo);
        usuario = AccesoBD.getInstance().obtenerUsuarioBDcodigo(codigo);
    }

    if (usuario == null) {
       
        usuario = new UsuarioBD();
        usuario.setUsuario("");
        usuario.setNombre("");
        usuario.setClave("");
        usuario.setDireccion("");
        usuario.setCP("");
        usuario.setTelefono("");
        usuario.setCorreo("");
    }

    request.setAttribute("usuario", usuario);
    request.getRequestDispatcher("modificarusuario.jsp").forward(request, response);
}

}