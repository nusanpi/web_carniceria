package tienda;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public final class AccesoBD {
	private static AccesoBD instanciaUnica = null;
	private Connection conexionBD = null;

	public static AccesoBD getInstance(){
		if (instanciaUnica == null){
			instanciaUnica = new AccesoBD();
		}
		return instanciaUnica;
	}

	private AccesoBD() {
		abrirConexionBD();
	}

	public void abrirConexionBD() {
		if (conexionBD == null)
		{
			String JDBC_DRIVER = "org.mariadb.jdbc.Driver";
			// daw es el nombre de la base de datos que hemos creado con anterioridad.
			String DB_URL = "jdbc:mariadb://localhost:3306/bdweb";
			// El usuario root y su clave son los que se puso al instalar MariaDB.
			String USER = "root";
			String PASS = "DawLab";
			try {
				Class.forName(JDBC_DRIVER);
				conexionBD = DriverManager.getConnection(DB_URL,USER,PASS);
			}
			catch(Exception e) {
				System.err.println("No se ha podido conectar a la base de datos");
				System.err.println(e.getMessage());
                e.printStackTrace();
			}
		}
	}

	public List<ProductoBD> obtenerProductosBD() {
	abrirConexionBD();

	ArrayList<ProductoBD> productos = new ArrayList<>();

	try {
		
	String con = "SELECT codigo,descripcion,precio,existencias,imagen FROM productos";
		Statement s = conexionBD.createStatement();
		ResultSet resultado = s.executeQuery(con);
		while(resultado.next()){
			ProductoBD producto = new ProductoBD();
			producto.setCodigo(resultado.getInt("codigo"));
			producto.setDescripcion(resultado.getString("descripcion"));
			producto.setPrecio(resultado.getFloat("precio"));
			producto.setStock(resultado.getInt("existencias"));
			producto.setImagen(resultado.getString("imagen"));
			productos.add(producto);
		}
	}
	catch(Exception e) {
		System.err.println("Error ejecutando la consulta a la base de datos");
		System.err.println(e.getMessage());
	}

	return productos;
	}

	public int comprobarUsuarioBD(String usuario, String clave) {
		abrirConexionBD();
	
		int codigo = -1;
	
		try{
			String con = "SELECT codigo FROM usuarios WHERE usuario=? AND BINARY clave=? AND activo=1";
			PreparedStatement s = conexionBD.prepareStatement(con);
			s.setString(1,usuario);
			s.setString(2,clave);
	
			ResultSet resultado = s.executeQuery();
	
	
			if ( resultado.next() ) {
				codigo =  resultado.getInt("codigo");
			}
		}
		catch(Exception e) {
	
			System.err.println("Error verificando usuario/clave");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return codigo;
	}

	public int registrarUsuarioBD(String usuario, String clave, String nombre, String direccion, String CP, String telefono, String correo) {
		abrirConexionBD();
		int codigo = -1;
	
		try {
			String sql = "INSERT INTO usuarios (activo, admin, usuario, clave, nombre, direccion, CP, telefono, correo) VALUES (1,0,?, ?, ?, ?, ?, ?, ?)";
          
            PreparedStatement stmt = conexionBD.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            stmt.setString(1, usuario);
            stmt.setString(2, clave);
            stmt.setString(3, nombre);
            stmt.setString(4, direccion);
			stmt.setString(5, CP);
			stmt.setString(6, telefono);
			stmt.setString(7, correo);
			
			int filasInsertadas = stmt.executeUpdate();
	
		
			if (filasInsertadas > 0) {
				
				ResultSet generatedKeys = stmt.getGeneratedKeys();
				if (generatedKeys.next()) {
					codigo = generatedKeys.getInt(1);
				}
			}
		} catch (SQLException e) {
			
			System.err.println("Error al registrar usuario en la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return codigo;
	}

	public UsuarioBD obtenerUsuarioBDcodigo(int codigo) {
		abrirConexionBD();
		UsuarioBD usuario = null;
	
		try {
			String sql = "SELECT * FROM usuarios WHERE codigo = ?";
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setInt(1, codigo);
			ResultSet resultado = stmt.executeQuery();
	
			if (resultado.next()) {
				usuario = new UsuarioBD();
				usuario.setCodigo(resultado.getInt("codigo"));
				usuario.setUsuario(resultado.getString("usuario"));
				usuario.setClave(resultado.getString("clave"));
				usuario.setNombre(resultado.getString("nombre"));
				usuario.setDireccion(resultado.getString("direccion"));
				usuario.setCP(resultado.getString("CP"));
				usuario.setTelefono(resultado.getString("telefono"));
				usuario.setCorreo(resultado.getString("correo"));
			}
		} catch (SQLException e) {
	
			System.err.println("Error al obtener datos de usuario de la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return usuario;
	}

	public UsuarioBD obtenerUsuarioBD(String nombreUsuario) {
		abrirConexionBD();
		UsuarioBD usuario = null;
	
		try {
			String sql = "SELECT * FROM usuarios WHERE usuario = ?";
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setString(1, nombreUsuario);
			ResultSet resultado = stmt.executeQuery();
	
			if (resultado.next()) {
				usuario = new UsuarioBD();
				usuario.setCodigo(resultado.getInt("codigo"));
				usuario.setUsuario(resultado.getString("usuario"));
				usuario.setClave(resultado.getString("clave"));
				usuario.setNombre(resultado.getString("nombre"));
				usuario.setDireccion(resultado.getString("direccion"));
				usuario.setCP(resultado.getString("CP"));
				usuario.setTelefono(resultado.getString("telefono"));
				usuario.setCorreo(resultado.getString("correo"));
			}
		} catch (SQLException e) {
			System.err.println("Error al obtener datos de usuario de la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return usuario;
	}
	public boolean modificarUsuarioBD(UsuarioBD usuario) {
		abrirConexionBD();
		boolean exito = false;
	
		try {
			String sql = "UPDATE usuarios SET usuario=?, clave=?, nombre=?, direccion=?, cp=?, telefono=?, correo=? WHERE codigo=?";
			
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setString(1, usuario.getUsuario());
			stmt.setString(2, usuario.getClave());
			stmt.setString(3, usuario.getNombre());
			stmt.setString(4, usuario.getDireccion());
			stmt.setString(5, usuario.getCP());
			stmt.setString(6, usuario.getTelefono());
			stmt.setString(7, usuario.getCorreo());
			stmt.setInt(8, usuario.getCodigo());
			
			int filasActualizadas = stmt.executeUpdate();
	
			if (filasActualizadas > 0) {
				exito = true;
			}
		} catch (SQLException e) {
			System.err.println("Error al modificar usuario en la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return exito;
	}

	public boolean modificarDireccionCPUsuarioBD(UsuarioBD usuario) {
		abrirConexionBD();
		boolean exito = false;
	
		try {
			String sql = "UPDATE usuarios SET direccion=?, cp=? WHERE codigo=?";
	
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setString(1, usuario.getDireccion());
			stmt.setString(2, usuario.getCP());
			stmt.setInt(3, usuario.getCodigo());
	
			int filasActualizadas = stmt.executeUpdate();
	
			if (filasActualizadas > 0) {
				exito = true;
			}
		} catch (SQLException e) {
			System.err.println("Error al modificar dirección y código postal del usuario en la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return exito;
	}
	

	public ProductoBD obtenerProductoBDcodigo(int codigo) {
		abrirConexionBD();
	
		try {
			String consulta = "SELECT codigo, descripcion, precio, existencias, imagen FROM productos WHERE codigo = ?";
			PreparedStatement ps = conexionBD.prepareStatement(consulta);
			ps.setInt(1, codigo);
			ResultSet resultado = ps.executeQuery();
	
			if (resultado.next()) {
				ProductoBD producto = new ProductoBD();
				producto.setCodigo(resultado.getInt("codigo"));
				producto.setDescripcion(resultado.getString("descripcion"));
				producto.setPrecio(resultado.getFloat("precio"));
				producto.setStock(resultado.getInt("existencias"));
				producto.setImagen(resultado.getString("imagen"));
				return producto;
			} else {
				return null;
			}
		} catch (Exception e) {
			System.err.println("Error ejecutando la consulta a la base de datos");
			System.err.println(e.getMessage());
			return null;
		}  
	}
	


	public int insertarPedidoBD(Pedidos pedido) {
		abrirConexionBD();
		int idPedido = -1;
	
		try {
			
			String sql = "INSERT INTO pedidos (persona, fecha, importe, estado) VALUES (?, NOW(), ?, ?)";
			PreparedStatement stmt = conexionBD.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setInt(1, pedido.getPersona());
			stmt.setFloat(2, pedido.getImporte());
			stmt.setInt(3, pedido.getEstado());
	
			int filasInsertadas = stmt.executeUpdate();
	
	
			if (filasInsertadas > 0) {
				ResultSet generatedKeys = stmt.getGeneratedKeys();
				if (generatedKeys.next()) {
					idPedido = generatedKeys.getInt(1);
				}
			}
		} catch (SQLException e) {
			System.err.println("Error al insertar pedido en la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}  
	
		return idPedido;
	}
	
	public int insertarDetalleBD(Detalles detalle){


		abrirConexionBD();
		int idDetalle = -1;
	
		try {
			
			String sql = "INSERT INTO detalle (codigo_pedido, codigo_producto, unidades, precio_unitario) VALUES (?, ?, ?, ?)";
			PreparedStatement stmt = conexionBD.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setInt(1, detalle.getCodigo_pedido());
			stmt.setInt(2, detalle.getCodigo_producto());
			stmt.setInt(3, detalle.getUnidades());
			stmt.setFloat(4, detalle.getPrecio_unitario());
	
			
			int filasInsertadas = stmt.executeUpdate();
	
			
			if (filasInsertadas > 0) {
				
				ResultSet generatedKeys = stmt.getGeneratedKeys();
				if (generatedKeys.next()) {
					idDetalle = generatedKeys.getInt(1);
				}
			}
		} catch (SQLException e) {
			
			System.err.println("Error al insertar detalle en la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}  
	
		return idDetalle;
	}

	public List<Detalles> obtenerDetallesPedido(int codigoPedido) {
		abrirConexionBD();
		List<Detalles> detalles = new ArrayList<>();
	
		try {
			String sql = "SELECT * FROM detalle WHERE codigo_pedido = ?";
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setInt(1, codigoPedido);
			ResultSet resultado = stmt.executeQuery();
	
			while (resultado.next()) {
				Detalles detalle = new Detalles();
				detalle.setCodigo_pedido(resultado.getInt("codigo_pedido"));
				detalle.setCodigo_producto(resultado.getInt("codigo_producto"));
				detalle.setUnidades(resultado.getInt("unidades"));
				detalle.setPrecio_unitario(resultado.getFloat("precio_unitario"));
				detalles.add(detalle);
			}
		} catch (SQLException e) {
			System.err.println("Error al obtener detalles de pedido de la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return detalles;
	}

	public List<Pedidos> mostrarPedidosUsuario(int codigoUsuario){
		abrirConexionBD();
		List<Pedidos> pedidos = new ArrayList<>();
	
		try {
			String sql = "SELECT * FROM pedidos WHERE persona = ?";
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setInt(1, codigoUsuario);
			ResultSet resultado = stmt.executeQuery();
	
			while (resultado.next()) {
				Pedidos pedido = new Pedidos();
				pedido.setCodigo(resultado.getInt("codigo"));
				pedido.setPersona(resultado.getInt("persona"));
				pedido.setFecha(resultado.getString("fecha"));
				pedido.setImporte(resultado.getFloat("importe"));
				pedido.setEstado(resultado.getInt("estado"));
				pedidos.add(pedido);
			}
		} catch (SQLException e) {
			System.err.println("Error al obtener pedidos de usuario de la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return pedidos;
	}


	public boolean eliminarPedido(int codigoPedido) {
		abrirConexionBD();
		boolean exito = false;
	
		try {
			String sql = "UPDATE pedidos SET estado= 4 WHERE codigo = ?";
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setInt(1, codigoPedido);
			int filasEliminadas = stmt.executeUpdate();
	
			if (filasEliminadas > 0) {
				exito = true;
			}
		} catch (SQLException e) {
			System.err.println("Error al eliminar pedido de la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return exito;
	}

	public Pedidos obtenerPedido(int codigoPedido) {
		abrirConexionBD();
		Pedidos pedido = null;
	
		try {
			String sql = "SELECT * FROM pedidos WHERE codigo = ?";
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setInt(1, codigoPedido);
			ResultSet resultado = stmt.executeQuery();
	
			if (resultado.next()) {
				pedido = new Pedidos();
				pedido.setCodigo(resultado.getInt("codigo"));
				pedido.setPersona(resultado.getInt("persona"));
				pedido.setFecha(resultado.getString("fecha"));
				pedido.setImporte(resultado.getFloat("importe"));
				pedido.setEstado(resultado.getInt("estado"));
			}
		} catch (SQLException e) {
			System.err.println("Error al obtener pedido de la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return pedido;
	}

	public void actualizarExistenciasProducto(int codigoProducto, int cantidadPedida) {
        abrirConexionBD();
        try {
            String sql = "UPDATE productos SET existencias = existencias - ? WHERE codigo = ?";
            PreparedStatement stmt = conexionBD.prepareStatement(sql);
            stmt.setInt(1, cantidadPedida);
            stmt.setInt(2, codigoProducto);

        } catch (SQLException e) {
            System.err.println("Error al actualizar las existencias del producto en la base de datos");
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }

	public void sumarExistenciasProducto(int codigoProducto, int cantidadCancelada) {
		abrirConexionBD();
		try {
			String sql = "UPDATE productos SET existencias = existencias + ? WHERE codigo = ?";
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setInt(1, cantidadCancelada);
			stmt.setInt(2, codigoProducto);
			 
		} catch (SQLException e) {
			System.err.println("Error al sumar las existencias del producto en la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}
	//funcion para ver los detalles de un pedido
	public List<Detalles> verDetallesPedido(int codigoPedido) {
		abrirConexionBD();
		List<Detalles> detalles = new ArrayList<>();
	
		try {
			String sql = "SELECT dp.codigo_pedido, p.descripcion, dp.unidades, dp.precio_unitario " +
						 "FROM detalle dp " +
						 "JOIN productos p ON dp.codigo_producto = p.codigo " +
						 "WHERE dp.codigo_pedido = ?";
			PreparedStatement stmt = conexionBD.prepareStatement(sql);
			stmt.setInt(1, codigoPedido);
			ResultSet resultado = stmt.executeQuery();
	
			while (resultado.next()) {
				Detalles detalle = new Detalles();
				detalle.setCodigo_pedido(resultado.getInt("codigo_pedido"));
				detalle.setDescripcion_producto(resultado.getString("descripcion"));
				detalle.setUnidades(resultado.getInt("unidades"));
				detalle.setPrecio_unitario(resultado.getFloat("precio_unitario"));
				detalles.add(detalle);
			}
		} catch (SQLException e) {
			System.err.println("Error al obtener detalles del pedido de la base de datos");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	
		return detalles;
	}
	
}