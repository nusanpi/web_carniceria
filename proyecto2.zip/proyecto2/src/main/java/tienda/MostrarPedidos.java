package tienda;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 
public class MostrarPedidos extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        int codigoUsuario = (int) request.getSession().getAttribute("usuario");
        
        
        AccesoBD accesoBD = AccesoBD.getInstance();
        List<Pedidos> pedidos = accesoBD.mostrarPedidosUsuario(codigoUsuario);
        
       
        request.setAttribute("pedidos", pedidos);
        
        request.getRequestDispatcher("pedidos.jsp").forward(request, response);
    }
}
