package tienda;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


public class Tramitacion extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String codigoUsuarioParam = request.getParameter("codigo");
        
        int codigoUsuario = Integer.parseInt(codigoUsuarioParam);
        
    
        // Obtener el objeto UsuarioBD utilizando el código de usuario
        AccesoBD accesoBD = AccesoBD.getInstance();
        
    
        // Obtener el carrito de la sesión
        HttpSession session = request.getSession();
        List<Producto> carrito = (List<Producto>) session.getAttribute("carrito");

        // Calcular el importe total
        float importeTotal = 0.0f;
        for (Producto producto : carrito) {
            importeTotal += producto.getPrecio() * producto.getCantidad();
        }
    
        Pedidos pedido = new Pedidos();
        pedido.setPersona(codigoUsuario);
        pedido.setImporte(importeTotal);
        pedido.setEstado(1); 
       
        
        int idPedido = accesoBD.insertarPedidoBD(pedido);
    
        if (idPedido != -1) {
            for (Producto producto : carrito) {
                Detalles detalle = new Detalles();
                detalle.setCodigo_pedido(idPedido);
                detalle.setCodigo_producto(producto.getCodigo());
                detalle.setUnidades(producto.getCantidad());
                detalle.setPrecio_unitario(producto.getPrecio());
                accesoBD.insertarDetalleBD(detalle);
                int cantidadPedida = producto.getCantidad();
                int codigoProducto = producto.getCodigo();
                accesoBD.actualizarExistenciasProducto(codigoProducto, cantidadPedida);
                
            }
            session.removeAttribute("carrito");
            request.setAttribute("pedido", idPedido);
            request.getRequestDispatcher("confirmacion.jsp").forward(request, response);
        } else {
           session.setAttribute("mensaje", "Error al tramitar el pedido");
            request.getRequestDispatcher("carrito.jsp").forward(request, response);
        }
    }
}
