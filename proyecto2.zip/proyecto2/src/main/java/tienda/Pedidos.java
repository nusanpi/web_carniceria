package tienda;

 

public class Pedidos {
    private int codigo;
    private int persona;
    private String fecha;
    private float importe;
    private int estado;

    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public int getPersona() {
        return persona;
    }
    public void setPersona(int persona) {
        this.persona = persona;
    }
    public String getFecha() {
        return fecha;
    }
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public float getImporte() {
        return importe;
    }
    public void setImporte(float importe) {
        this.importe = importe;
    }
    public int getEstado() {
        return estado;
    }
    public void setEstado(int estado) {
        this.estado = estado;
    }

    public  String obtenerEstado() {
        String resultado = "";
        switch(estado) {
            case 1:
            resultado = "Pendiente";
                break;
            case 2:
            resultado = "Enviado";
                break;
            case 3:
            resultado = "Entregado";
                break;
            case 4:
            resultado = "Cancelado";
                break;
            default:
            resultado = "Desconocido";
        }
        return resultado;
    }
}
