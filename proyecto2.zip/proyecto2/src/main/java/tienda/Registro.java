package tienda;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Registro extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        String usuario = request.getParameter("usuario");
        String clave = request.getParameter("clave");
        String nombre = request.getParameter("nombre");
        String direccion = request.getParameter("direccion");
        String CP = request.getParameter("CP");
        String telefono = request.getParameter("telefono");
        String correo = request.getParameter("correo");

        if (usuario.trim().isEmpty() || clave.trim().isEmpty() || nombre.trim().isEmpty() || direccion.trim().isEmpty() || CP.trim().isEmpty() || telefono.trim().isEmpty() || correo.trim().isEmpty()) {
            request.setAttribute("mensaje1", "Por favor, complete todos los campos.");
            request.getRequestDispatcher("registro.jsp").forward(request, response);
        } else {
            AccesoBD accesoBD = AccesoBD.getInstance();
    
            int codigoUsuario = accesoBD.registrarUsuarioBD(usuario, clave, nombre, direccion, CP, telefono, correo);

            if (codigoUsuario > 0) {

                response.sendRedirect("loginUsuario.jsp");
            } else {
            
                request.setAttribute("mensaje", "Error al registrar el usuario. Inténtelo de nuevo.");
                request.getRequestDispatcher("registro.jsp").forward(request, response);
            }
        }
    }
}
