class Cabecera extends HTMLElement {
    constructor() {
        super()
        this.innerHTML = 

`
<header>
<div class="container-cabecera">
<nav  class="navbar navbar-expand-lg ">
        <div class="container ">
                <a class="navbar-brand" >
                    <img src="./img/logo.png" alt="Logo">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
               <mi-menu></mi-menu>
              </div>
        </div>
        </div>
</nav> 
 
</header>
`
    }
}
window.customElements.define('mi-cabecera', Cabecera);

class Pie extends HTMLElement {
    constructor() {
        super()
        this.innerHTML = `<footer >
        
        
        <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h4>Información de contacto</h4>
                <p>665586672</p>
                <p>elsquitos@gmail.com</p>
                <p>Avenida de Gandia,17</p>
            </div>
            <div class="col-md-6">
                <h4>Redes Sociales</h4>
                <ul class="redes-sociales">
                    <a href="https://www.facebook.com/" target="_blank" class="facebook"><i class="fab fa-facebook "></i></a>
                    <a href="https://twitter.com/" target="_blank" ><i class="fab fa-twitter"></i></a>
                    <a href="https://www.instagram.com/" target="_blank" class="instagram"><i class="fab fa-instagram personalizar-color"></i></a>
                    
                </ul>
            </div>
        </div>
    </div>
    &copy; 2024 - Els Quitos S.L. - 
    </footer>    
        `
    }
}
window.customElements.define('mi-pie', Pie);

class Menu extends HTMLElement {
    constructor() {
        super()
        this.innerHTML = 
       
        `
        <nav class="navbar navbar-expand-lg ">
            
        
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ">
                    <li class="nav-item active"><a class="nav-link" href="index.html"> Inicio</a></li>
                    <li class="nav-item"><a class="nav-link" href="empresa.html"> Empresa</a></li>
                    <li class="nav-item"><a class="nav-link" href="producto.jsp"> Productos</a></li>
                    <li class="nav-item"><a class="nav-link" href="contacto.html"> Contacto</a></li>
                    <li class="nav-item"><a class="nav-link" href="carrito.jsp"> <i class="fa-solid fa-cart-shopping"></i></a></li>
                    <li class="nav-item"><a class="nav-link" href="loginUsuario.jsp"> <i class="fa-regular fa-user"></i></a></li>
                </ul>
            </div>
        </nav>
        `
        
    }
}
window.customElements.define('mi-menu', Menu);
