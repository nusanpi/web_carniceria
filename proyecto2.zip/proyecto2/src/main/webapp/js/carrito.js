var carrito = []; 
var producto = new Object()



function cargarCarrito() {
    // Verificamos si el carrito almacenado existe en el localStorage
    var carritoAlmacenado = localStorage.getItem("mi-carrito-almacenado");
    if (carritoAlmacenado !== null) { // Si hay un carrito almacenado
        // Cargamos el carrito almacenado
        carrito = JSON.parse(carritoAlmacenado);
    } else { // Si no existía carrito almacenado
        carrito = []; // Creamos un vector vacío
    }
}


function guardarCarrito() {
	localStorage.setItem("mi-carrito-almacenado",JSON.stringify(carrito));
}




function mostrarCarrito() {
    cargarCarrito();
    var total = 0;
    var tabla = "<table class='table table-striped'>";
    tabla += "<thead><tr><th>Nombre</th><th>Cantidad</th><th>Precio</th><th>Eliminar</th></tr></thead><tbody>";
    for (var i = 0; i < carrito.length; i++) {
        tabla += "<tr>";
        tabla += "<td>" + carrito[i].nombre + "</td>";
        tabla += "<td><input type='number' class='form-control' value='" + carrito[i].cantidad + "' onchange='modificarCantidad(\"" + carrito[i].codigo + "\", this.value)'></td>";
        tabla += "<td>" + carrito[i].precio + " €</td>";
        tabla += "<td><button class='btn btn-danger' onclick='eliminarDelCarrito(\"" + carrito[i].codigo + "\")'><i class='fas fa-trash'></i> Eliminar</button></td>";
        tabla += "</tr>";
        total += parseFloat((carrito[i].precio * carrito[i].cantidad).toFixed(2));
    }
    tabla += "<tr><td colspan='2'><strong>Total</strong></td><td colspan='2'>" + total.toFixed(2) + " €</td></tr>";
    tabla += "</tbody></table>";

    tabla += "<div class='d-flex justify-content-between'>";
    tabla += "<button class='btn btn-primary' onclick='vaciarCarrito()'><i class='fas fa-trash'></i> Vaciar Carrito</button>";
   
    tabla += "</div>";

    document.getElementById("carrito").innerHTML = tabla;
    
}




function anadirCarrito(identificador, nombre, precio, existencias) {
    cargarCarrito();
    
    
    if (existencias <= 0) {
        alert("No hay suficientes existencias disponibles para el producto \"" + nombre + "\"");
        return; 
    }

    var productoExistente = carrito.find(function(producto) {
        return producto.codigo == identificador;
    });

    var cantidadAAgregar = 1; 

    if (productoExistente) {
        cantidadAAgregar = productoExistente.cantidad + 1;
    }

    if (cantidadAAgregar > existencias) {
        alert("No hay suficientes existencias disponibles para agregar " + cantidadAAgregar + " unidades del producto \"" + nombre + "\"");
        return; 
    }

    if (productoExistente) {
       
        productoExistente.cantidad++;
        alert("Cantidad de " + nombre + " en el carrito actualizada a: " + productoExistente.cantidad);
    } else {
       
        var nuevoProducto = {
            codigo: identificador,
            nombre: nombre,
            precio: precio,
            existencias: existencias, 
            cantidad: 1
        };
        carrito.push(nuevoProducto);
        alert("Producto \"" + nombre + "\" añadido al carrito");
    }

    
    guardarCarrito();
    console.log(carrito);
}



function eliminarDelCarrito(identificador) {
    
    cargarCarrito();
    for (var i = 0; i < carrito.length; i++) {
        if (carrito[i].codigo == identificador) {
            carrito.splice(i, 1);
        }
    }
    alert("Producto eliminado del carrito");
    guardarCarrito();
    mostrarCarrito();
}

function modificarCantidad(identificador, cantidad) {
    cargarCarrito();
    
   
    var productoEnCarrito = carrito.find(function(producto) {
        return producto.codigo == identificador;
    });

    
    if (!productoEnCarrito) {
        alert("El producto no está en el carrito");
        return;
    }

    
    if (cantidad > productoEnCarrito.existencias) {
        alert("No hay suficientes existencias disponibles para modificar la cantidad del producto.");
        return;
    }

    
    productoEnCarrito.cantidad = parseInt(cantidad);

    if (cantidad <= 0) {
        eliminarDelCarrito(identificador);
        return; 
    }

    guardarCarrito();
    alert("Cantidad modificada");
    mostrarCarrito();
}



function vaciarCarrito() {
    carrito = [];
    guardarCarrito();
   
    mostrarCarrito();
}



function generarTicketDeCompra() {
    cargarCarrito();
    var total = 0;
    var ticket = "<div class='ticket-container'>"; 
    ticket += "<div class='ticket-header'>";
    ticket += "<h2>Ticket de Compra</h2>";
    ticket += "</div>"; 
    ticket += "<div class='ticket-items'>";  
    ticket += "<ul class='list-group'>";  
    for (var i = 0; i < carrito.length; i++) {
        var precioUnitario = carrito[i].precio.toFixed(2);
        var totalProducto = (carrito[i].precio * carrito[i].cantidad).toFixed(2);  
        ticket += "<li class='list-group-item d-flex justify-content-between align-items-center'>";  
        ticket += "<div class='d-flex flex-column'>";  
        ticket += "<span>" + carrito[i].nombre + "</span>";  
        ticket += "<span class='align-self-center'>Precio Unitario: " + precioUnitario + " €</span>";  
        ticket += "<span>Cantidad: " + carrito[i].cantidad + "</span>"; 
        ticket += "</div>";  
        ticket += "<span>Total: " + totalProducto + " €</span>"; 
        ticket += "</li>";  
        total += parseFloat(totalProducto);  
    }
    ticket += "</ul>";  
    ticket += "</div>";  
    ticket += "<div class='ticket-total'>";  
    ticket += "<p>Total: " + total.toFixed(2) + " €</p>"; 
    ticket += "</div>";  
    ticket += "</div>";  
    
    document.getElementById("ticket").innerHTML = ticket;

}

function obtenerCarrito() {
    cargarCarrito();
    
    return carrito;
}




 
